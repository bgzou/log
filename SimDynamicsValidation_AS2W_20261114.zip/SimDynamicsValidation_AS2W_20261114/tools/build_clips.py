#!/usr/bin/env python3
"""Rebuild the aligned replay clips from the raw AS2-W logs in data/raw.

Usage (from the package root):
    python tools/build_clips.py

Every clip is written as clips/<name>/clip.npz + clips/<name>/meta.json.
The CSV index is clips/index.csv.

Conventions (also documented in docs/02_字段_关节序_对齐说明.md):
  * Joint order: contract order = 4 hips (FL,FR,RL,RR), 4 thighs, 4 calves,
    4 wheels (FL,FR,RL,RR).
  * All arrays in the clips use the project contract/model sign. The raw
    LowCmd q and LowState q are DDS sign; hips are inverted (sign=-1).
  * cmd_tick and st_tick are the LowState 1 kHz tick counters. A command row
    is aligned to the nearest state row; st_offset_ms = st_tick - cmd_tick.
  * Frequency: 500 Hz (2 ms) for all command-replay clips; the factory clip
    is 100 Hz because its source capture is 10 ms.
"""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
CLIPS = ROOT / "clips"

JOINTS = [
    "FL_hip", "FR_hip", "RL_hip", "RR_hip",
    "FL_thigh", "FR_thigh", "RL_thigh", "RR_thigh",
    "FL_calf", "FR_calf", "RL_calf", "RR_calf",
    "FL_wheel", "FR_wheel", "RL_wheel", "RR_wheel",
]
DDS_SLOTS = [3, 0, 9, 6, 4, 1, 10, 7, 5, 2, 11, 8, 13, 12, 15, 14]
SIGNS = np.array([-1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], dtype=np.float32)
STATE_NAMES = {
    0: "Passive",
    1: "FixStand",
    2: "FixedStand",
    3: "PolicyHandoff",
    4: "PolicyWalk",
    5: "Brake",
    6: "ReturnStand",
    7: "FixSquat",
    8: "EmergencyDamping",
}

# name, session, [tick_start, tick_end], tags, note
CLIP_SPEC = [
    ("220051_prone_passive", "20261112-220051_training-contract", (1697200, 1702200),
     "passive,contact,static", "趴姿 Passive 5 s；kp=0/kd=3，q 跟随实测；用于接触/阻尼/静摩擦基线"),
    ("220051_fixstand_rise", "20261112-220051_training-contract", (1712258, 1715259),
     "step,actuator,fixstand", "FixStand 两段起立（kp 20/3 → 55/2）纯状态段；用于 PD/执行器阶跃响应"),
    ("220051_fixedstand_hold", "20261112-220051_training-contract", (1715259, 1718919),
     "static,gravity,fixedstand", "T2 FixedStand 保持 3.66 s 纯状态段；用于重力/CoM/静态 PD 误差校验"),
    ("220051_handoff_zero", "20261112-220051_training-contract", (1718919, 1724920),
     "handoff,zero,policy", "PolicyHandoff 2 s + 零速 PolicyWalk 8 s；用于接管瞬态与零速闭环"),
    ("220051_brake_return", "20261112-220051_training-contract", (1742000, 1742697),
     "brake,wheel", "Brake + ReturnStand 约 0.7 s；轮速目标归零，用于轮-地摩擦/制动"),
    ("220051_fixsquat", "20261112-220051_training-contract", (1742697, 1749699),
     "squat,contact,large_motion", "FixSquat 7 s；大幅腿运动+落地接触，用于接触模型/关节摩擦"),
    ("112630_fixstand_rise", "20261113-112630_r4000", (617466, 620468),
     "step,actuator,fixstand", "R4000 会话的 FixStand 起立纯状态段，用于跨会话重复性"),
    ("112630_fixedstand_hold", "20261113-112630_r4000", (620468, 622847),
     "static,gravity,fixedstand", "R4000 会话的 T2 保持 2.38 s 纯状态段"),
    ("112630_policy_walk_30s", "20261113-112630_r4000", (624845, 654865),
     "walk,contact,policy", "R4000 30 s 行走（命令 ±0.2 m/s 内）；用于行走/接触/轮速闭环"),
    ("112630_brake_return", "20261113-112630_r4000", (654865, 657925),
     "brake,return,wheel", "Brake 0.54 s + ReturnStand 2.5 s；用于轮速衰减与回站混合"),
    ("112630_fixsquat", "20261113-112630_r4000", (663445, 670444),
     "squat,contact,large_motion", "FixSquat 7 s"),
    ("114335_fixstand_rise", "20261113-114335_r4000", (1647632, 1650632),
     "step,actuator,fixstand", "R4000 长会话的 FixStand 起立纯状态段"),
    ("114335_fixedstand_hold", "20261113-114335_r4000", (1650632, 1652851),
     "static,gravity,fixedstand", "R4000 长会话的 T2 保持 2.22 s 纯状态段"),
    ("114335_walk_00_30", "20261113-114335_r4000", (1654852, 1684852),
     "walk,contact,policy", "120 s 行走的第 1 个 30 s；命令可达 ±0.4 m/s、wz ±0.1"),
    ("114335_walk_30_60", "20261113-114335_r4000", (1684852, 1714852),
     "walk,contact,policy", "120 s 行走的第 2 个 30 s"),
    ("114335_walk_60_90", "20261113-114335_r4000", (1714852, 1744852),
     "walk,contact,policy", "120 s 行走的第 3 个 30 s"),
    ("114335_walk_90_120", "20261113-114335_r4000", (1744852, 1774869),
     "walk,contact,policy", "120 s 行走的第 4 个 30 s（含尾段）"),
    ("114335_brake_return", "20261113-114335_r4000", (1774869, 1777708),
     "brake,return,wheel", "Brake 0.32 s + ReturnStand 2.5 s"),
    ("114335_fixsquat", "20261113-114335_r4000", (1779629, 1786628),
     "squat,contact,large_motion", "FixSquat 7 s"),
]


def parse_capture(path: Path) -> dict:
    tick, t_s, quat, gyro = [], [], [], []
    q_raw, dq_raw, tau_raw, mode = [], [], [], []
    q, dq, tau = [], [], []
    with path.open(errors="replace") as stream:
        for line in stream:
            if "LOW_SAMPLE," not in line or "LOW_SAMPLE_SCHEMA" in line:
                continue
            pos = line.find("LOW_SAMPLE,")
            p = line[pos:].strip().split(",")
            if len(p) < 224:
                continue
            tick.append(int(float(p[4])))
            t_s.append(float(p[1]) / 1000.0)
            quat.append([float(p[7 + i]) for i in range(4)])
            gyro.append([float(p[11 + i]) for i in range(3)])
            qr, dqr, taur, qm, dqm, taum, mode_row = [], [], [], [], [], [], []
            for i, slot in enumerate(DDS_SLOTS):
                base = 14 + slot * 6
                qr.append(float(p[base]))
                dqr.append(float(p[base + 1]))
                taur.append(float(p[base + 3]))
                qm.append(SIGNS[i] * qr[-1])
                dqm.append(SIGNS[i] * dqr[-1])
                taum.append(SIGNS[i] * taur[-1])
                mode_row.append(int(float(p[base + 4])))
            q_raw.append(qr)
            dq_raw.append(dqr)
            tau_raw.append(taur)
            q.append(qm)
            dq.append(dqm)
            tau.append(taum)
            mode.append(mode_row)
    return {
        "tick": np.asarray(tick, dtype=np.int64),
        "t_s": np.asarray(t_s, dtype=np.float32),
        "quat": np.asarray(quat, dtype=np.float32),
        "gyro": np.asarray(gyro, dtype=np.float32),
        "q_raw": np.asarray(q_raw, dtype=np.float32),
        "dq_raw": np.asarray(dq_raw, dtype=np.float32),
        "tau_raw": np.asarray(tau_raw, dtype=np.float32),
        "q": np.asarray(q, dtype=np.float32),
        "dq": np.asarray(dq, dtype=np.float32),
        "tau": np.asarray(tau, dtype=np.float32),
        "mode": np.asarray(mode, dtype=np.int16),
    }


def parse_lowcmd(path: Path) -> dict:
    tick, state, mode_machine, mono = [], [], [], []
    q_raw, dq_raw, tau_raw = [], [], []
    q, dq, kp, kd, tau = [], [], [], [], []
    with path.open(newline="", errors="replace") as stream:
        for row in csv.reader(stream):
            if not row or row[0] != "DEBUG_LOWCMD":
                continue
            values = [float(v) for v in row[5:5 + 7 * 16]]
            if len(values) < 7 * 16:
                continue
            mono.append(int(row[1]))
            tick.append(int(row[2]))
            state.append(int(row[3]))
            mode_machine.append(int(row[4]))
            qr = [values[i * 7 + 2] for i in range(16)]
            dqr = [values[i * 7 + 3] for i in range(16)]
            taur = [values[i * 7 + 6] for i in range(16)]
            q_raw.append(qr)
            dq_raw.append(dqr)
            tau_raw.append(taur)
            q.append([SIGNS[i] * qr[i] for i in range(16)])
            dq.append([SIGNS[i] * dqr[i] for i in range(16)])
            kp.append([values[i * 7 + 4] for i in range(16)])
            kd.append([values[i * 7 + 5] for i in range(16)])
            tau.append([SIGNS[i] * taur[i] for i in range(16)])
    mono = np.asarray(mono, dtype=np.int64)
    return {
        "mono_ns": mono,
        "t_s": (mono - mono[0]).astype(np.float64) / 1e9,
        "tick": np.asarray(tick, dtype=np.int64),
        "state": np.asarray(state, dtype=np.int16),
        "mode_machine": np.asarray(mode_machine, dtype=np.int16),
        "q_raw": np.asarray(q_raw, dtype=np.float32),
        "dq_raw": np.asarray(dq_raw, dtype=np.float32),
        "tau_raw": np.asarray(tau_raw, dtype=np.float32),
        "q": np.asarray(q, dtype=np.float32),
        "dq": np.asarray(dq, dtype=np.float32),
        "kp": np.asarray(kp, dtype=np.float32),
        "kd": np.asarray(kd, dtype=np.float32),
        "tau": np.asarray(tau, dtype=np.float32),
    }


def nearest_indices(st_tick: np.ndarray, cmd_tick: np.ndarray) -> np.ndarray:
    idx = np.searchsorted(st_tick, cmd_tick)
    idx = np.clip(idx, 0, len(st_tick) - 1)
    prev = np.clip(idx - 1, 0, len(st_tick) - 1)
    take_prev = np.abs(st_tick[prev] - cmd_tick) < np.abs(st_tick[idx] - cmd_tick)
    return np.where(take_prev, prev, idx)


def write_clip(name: str, session: str, t0: int, t1: int, tags: str, note: str,
               capture: dict, lowcmd: dict | None) -> dict:
    out_dir = CLIPS / name
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)

    st_mask = (capture["tick"] >= t0) & (capture["tick"] <= t1)
    st_tick = capture["tick"][st_mask]
    st_t_s = capture["t_s"][st_mask]
    st_q_raw = capture["q_raw"][st_mask]
    st_dq_raw = capture["dq_raw"][st_mask]
    st_tau_raw = capture["tau_raw"][st_mask]
    st_q = capture["q"][st_mask]
    st_dq = capture["dq"][st_mask]
    st_tau = capture["tau"][st_mask]
    st_mode = capture["mode"][st_mask]
    quat = capture["quat"][st_mask]
    gyro = capture["gyro"][st_mask]

    if lowcmd is None:
        # State-only reference (factory stand): no LowCmd in the source.
        clip_start_s = float(st_t_s[0]) if len(st_t_s) else 0.0
        np.savez_compressed(
            out_dir / "clip.npz",
            tick=st_tick,
            t_s=(st_t_s - clip_start_s).astype(np.float32),
            st_q_raw=st_q_raw, st_dq_raw=st_dq_raw, st_tau_raw=st_tau_raw,
            st_q=st_q, st_dq=st_dq, st_tau=st_tau, st_mode=st_mode,
            quat=quat, gyro=gyro,
            joint_names=np.asarray(JOINTS),
            dds_slots=np.asarray(DDS_SLOTS, dtype=np.int16),
            signs=SIGNS.astype(np.int8),
            state_names=np.asarray([STATE_NAMES[i] for i in range(9)]),
        )
        meta = {
            "name": name, "source_session": session,
            "source_files": ["low_capture_fast.log"],
            "tick_start": int(st_tick[0]), "tick_end": int(st_tick[-1]),
            "duration_s": round(float(st_t_s[-1] - st_t_s[0]), 3),
            "rate_hz": 100.0, "n_cmd": 0, "n_state": int(len(st_tick)),
            "test_tags": tags.split(","), "states": ["factory_stand"],
            "notes": note,
            "sign_convention": "st_* is model sign (sign*raw); st_*_raw is DDS sign",
            "state_only": True,
        }
        (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"n_cmd": 0, "max_wheel_dq": float("nan"), "max_gyro_z": float(np.max(np.abs(gyro[:, 2]))) if len(gyro) else float("nan")}

    cmd_mask = (lowcmd["tick"] >= t0) & (lowcmd["tick"] <= t1)
    cmd_tick = lowcmd["tick"][cmd_mask]
    cmd_state = lowcmd["state"][cmd_mask]
    cmd_mode_machine = lowcmd["mode_machine"][cmd_mask]
    cmd_q_raw = lowcmd["q_raw"][cmd_mask]
    cmd_dq_raw = lowcmd["dq_raw"][cmd_mask]
    cmd_tau_raw = lowcmd["tau_raw"][cmd_mask]
    cmd_q = lowcmd["q"][cmd_mask]
    cmd_dq = lowcmd["dq"][cmd_mask]
    cmd_kp = lowcmd["kp"][cmd_mask]
    cmd_kd = lowcmd["kd"][cmd_mask]
    cmd_tau = lowcmd["tau"][cmd_mask]
    cmd_t_s = lowcmd["t_s"][cmd_mask] - lowcmd["t_s"][cmd_mask][0]

    idx = nearest_indices(st_tick, cmd_tick)
    st_off = (st_tick[idx] - cmd_tick).astype(np.int16)
    base_tick = int(cmd_tick[0])

    np.savez_compressed(
        out_dir / "clip.npz",
        cmd_tick=cmd_tick, cmd_t_s=cmd_t_s.astype(np.float32),
        cmd_state=cmd_state, cmd_mode_machine=cmd_mode_machine,
        cmd_q_raw=cmd_q_raw, cmd_dq_raw=cmd_dq_raw, cmd_tau_raw=cmd_tau_raw,
        cmd_q=cmd_q, cmd_dq=cmd_dq, cmd_kp=cmd_kp, cmd_kd=cmd_kd, cmd_tau=cmd_tau,
        st_tick=st_tick[idx], st_t_s=((st_tick[idx] - base_tick) / 1000.0).astype(np.float32),
        st_q_raw=st_q_raw[idx], st_dq_raw=st_dq_raw[idx], st_tau_raw=st_tau_raw[idx],
        st_q=st_q[idx], st_dq=st_dq[idx], st_tau=st_tau[idx], st_mode=st_mode[idx],
        st_offset_ms=st_off,
        quat=quat[idx], gyro=gyro[idx],
        joint_names=np.asarray(JOINTS),
        dds_slots=np.asarray(DDS_SLOTS, dtype=np.int16),
        signs=SIGNS.astype(np.int8),
        state_names=np.asarray([STATE_NAMES[i] for i in range(9)]),
    )

    states = sorted({STATE_NAMES.get(int(s), str(s)) for s in cmd_state})
    meta = {
        "name": name, "source_session": session,
        "source_files": ["debug_lowcmd.csv", "low_capture_fast.log"],
        "tick_start": int(cmd_tick[0]), "tick_end": int(cmd_tick[-1]),
        "duration_s": round(float(cmd_t_s[-1]), 3),
        "rate_hz": 500.0, "n_cmd": int(len(cmd_tick)), "n_state": int(len(st_tick)),
        "test_tags": tags.split(","), "states": states, "notes": note,
        "sign_convention": "cmd_*/st_* are model sign (sign*raw); cmd_*_raw/st_*_raw are DDS sign",
        "st_alignment": "nearest LowState tick; st_offset_ms = st_tick - cmd_tick; 1 tick = 1 ms",
        "state_only": False,
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "n_cmd": int(len(cmd_tick)),
        "max_wheel_dq": float(np.max(np.abs(cmd_dq[:, 12:16]))),
        "max_gyro_z": float(np.max(np.abs(gyro[idx, 2]))),
    }


def main() -> int:
    CLIPS.mkdir(exist_ok=True)
    cache: dict[str, dict] = {}
    index_rows = []

    for name, session, (t0, t1), tags, note in CLIP_SPEC:
        if session not in cache:
            raw = RAW / session
            cache[session] = {
                "capture": parse_capture(raw / "low_capture_fast.log"),
                "lowcmd": parse_lowcmd(raw / "debug_lowcmd.csv"),
            }
        stats = write_clip(name, session, t0, t1, tags, note,
                           cache[session]["capture"], cache[session]["lowcmd"])
        index_rows.append({
            "name": name, "session": session, "tick_start": t0, "tick_end": t1,
            "duration_s": round((t1 - t0) / 1000.0, 3), "n_cmd": stats["n_cmd"],
            "max_abs_cmd_wheel_dq": round(stats["max_wheel_dq"], 3) if stats["n_cmd"] else "",
            "max_abs_gyro_z": round(stats["max_gyro_z"], 3),
            "test_tags": tags, "notes": note,
        })
        print(f"wrote {name}: n_cmd={stats['n_cmd']}")

    # Factory stand: state-only reference, source is a 100 Hz capture, time in ms.
    factory = parse_capture(RAW / "20261109-185025_factory" / "low_capture_fast.log")
    mask = (factory["t_s"] >= 86.66) & (factory["t_s"] <= 92.96)
    # write_clip expects ticks for the range; use the capture tick range directly.
    t0 = int(factory["tick"][mask][0])
    t1 = int(factory["tick"][mask][-1])
    stats = write_clip("factory_stand", "20261109-185025_factory", t0, t1,
                       "factory,reference,static",
                       "原厂高层站立稳定窗 86.66–92.96 s；无 LowCmd，仅作 T1 姿态/力矩参考",
                       factory, None)
    index_rows.append({
        "name": "factory_stand", "session": "20261109-185025_factory",
        "tick_start": t0, "tick_end": t1, "duration_s": 6.3, "n_cmd": 0,
        "max_abs_cmd_wheel_dq": "", "max_abs_gyro_z": round(stats["max_gyro_z"], 3),
        "test_tags": "factory,reference,static", "notes": "无 LowCmd；仅姿态/力矩参考",
    })
    print("wrote factory_stand")

    with (CLIPS / "index.csv").open("w", newline="", encoding="utf-8") as stream:
        fieldnames = ["name", "session", "tick_start", "tick_end", "duration_s", "n_cmd",
                      "max_abs_cmd_wheel_dq", "max_abs_gyro_z", "test_tags", "notes"]
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(index_rows)
    print(f"index: {CLIPS / 'index.csv'} ({len(index_rows)} clips)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
