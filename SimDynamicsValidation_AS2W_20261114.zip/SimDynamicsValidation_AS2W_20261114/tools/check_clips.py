#!/usr/bin/env python3
"""Sanity-check every clip in clips/ (monotonic ticks, alignment, NaNs, ranges).

Usage:
    python tools/check_clips.py
Exit code 0 = all checks pass; 1 = at least one failure.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
CLIPS = ROOT / "clips"


def check_one(path: Path) -> list[str]:
    errors = []
    data = np.load(path / "clip.npz", allow_pickle=False)
    if "cmd_tick" in data:
        cmd_tick = data["cmd_tick"]
        st_tick = data["st_tick"]
        for key in ("cmd_q", "cmd_dq", "cmd_kp", "cmd_kd", "cmd_tau", "st_q", "st_dq", "st_tau"):
            arr = data[key]
            if arr.shape != (len(cmd_tick), 16):
                errors.append(f"{key} shape {arr.shape}")
            if not np.isfinite(arr).all():
                errors.append(f"{key} has NaN/Inf")
        if np.any(np.diff(cmd_tick) < 0):
            errors.append("cmd_tick decreasing")
        if np.any(np.diff(data["cmd_t_s"]) <= 0):
            errors.append("cmd_t_s not strictly increasing")
        if np.any(np.diff(st_tick) < 0):
            errors.append("st_tick not monotonic")
        off = data["st_offset_ms"]
        if np.abs(off).max() > 10:
            errors.append(f"st_offset_ms max {np.abs(off).max()} > 10")
    else:
        for key in ("st_q", "st_dq", "st_tau", "quat", "gyro"):
            arr = data[key]
            if arr.shape[0] != len(data["tick"]):
                errors.append(f"{key} length mismatch")
            if not np.isfinite(arr).all():
                errors.append(f"{key} has NaN/Inf")
        if np.any(np.diff(data["tick"]) <= 0):
            errors.append("tick not strictly increasing")
    if data["joint_names"].shape != (16,):
        errors.append("joint_names shape")
    return errors


def main() -> int:
    clips = sorted(p for p in CLIPS.iterdir() if p.is_dir())
    print(f"{'clip':32s} {'n':>7s} {'dur_s':>7s} {'states':>18s} {'max|w_dq|':>9s} {'max|wz|':>7s}  result")
    failed = 0
    for clip in clips:
        data = np.load(clip / "clip.npz", allow_pickle=False)
        errors = check_one(clip)
        n = len(data["cmd_tick"]) if "cmd_tick" in data else len(data["tick"])
        dur = float(data["cmd_t_s"][-1]) if "cmd_t_s" in data else float(data["t_s"][-1])
        if "cmd_state" in data:
            states = ",".join(sorted({str(int(s)) for s in data["cmd_state"]}))
            wheel = float(np.max(np.abs(data["cmd_dq"][:, 12:16])))
        else:
            states = "factory"
            wheel = float("nan")
        wz = float(np.max(np.abs(data["gyro"][:, 2])))
        result = "OK" if not errors else "FAIL: " + "; ".join(errors)
        if errors:
            failed += 1
        print(f"{clip.name:32s} {n:7d} {dur:7.2f} {states:>18s} {wheel:9.3f} {wz:7.3f}  {result}")
    print(f"\n{len(clips)} clips, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
