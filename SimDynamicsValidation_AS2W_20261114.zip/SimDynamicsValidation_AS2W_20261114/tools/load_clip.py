#!/usr/bin/env python3
"""Load one aligned AS2-W replay clip.

Usage:
    python tools/load_clip.py clips/220051_fixedstand_hold
    python tools/load_clip.py clips/114335_walk_00_30 --summary

Import:
    import sys; sys.path.insert(0, "tools")
    from load_clip import load
    c = load("clips/220051_fixedstand_hold")
    c["cmd_q"], c["st_q"], c["quat"], c["gyro"], c["meta"]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def load(path: str | Path) -> dict:
    p = Path(path)
    if p.is_dir():
        p = p / "clip.npz"
    data = dict(np.load(p, allow_pickle=False))
    meta_path = p.parent / "meta.json"
    if meta_path.exists():
        data["meta"] = json.loads(meta_path.read_text(encoding="utf-8"))
    return data


def summary(data: dict) -> str:
    lines = []
    meta = data.get("meta", {})
    name = meta.get("name", "?")
    lines.append(f"clip: {name}")
    lines.append(f"  source: {meta.get('source_session', '?')}")
    lines.append(f"  states: {meta.get('states', '?')}  tags: {meta.get('test_tags', '?')}")
    if "cmd_tick" in data:
        lines.append(f"  commands: {len(data['cmd_tick'])} rows @ {meta.get('rate_hz', '?')} Hz")
        lines.append(f"  duration: {data['cmd_t_s'][-1]:.3f} s")
        lines.append(f"  st_offset_ms: {int(data['st_offset_ms'].min())}..{int(data['st_offset_ms'].max())}")
        lines.append(f"  cmd_q model: min {data['cmd_q'].min():+.3f} max {data['cmd_q'].max():+.3f}")
        lines.append(f"  st_q  model: min {data['st_q'].min():+.3f} max {data['st_q'].max():+.3f}")
        lines.append(f"  wheel dq cmd: min {data['cmd_dq'][:, 12:16].min():+.3f} max {data['cmd_dq'][:, 12:16].max():+.3f}")
        lines.append(f"  gyro_z: min {data['gyro'][:, 2].min():+.3f} max {data['gyro'][:, 2].max():+.3f}")
    else:
        lines.append(f"  state-only: {len(data['tick'])} rows @ {meta.get('rate_hz', '?')} Hz")
        lines.append(f"  duration: {data['t_s'][-1]:.3f} s")
    lines.append(f"  joints: {', '.join(str(x) for x in data['joint_names'])}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("clip")
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args()
    data = load(args.clip)
    if args.summary:
        print(summary(data))
    else:
        print(sorted(data.files))
        if "cmd_tick" in data:
            print("cmd_tick", data["cmd_tick"].shape, "st_tick", data["st_tick"].shape)
        else:
            print("tick", data["tick"].shape)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
