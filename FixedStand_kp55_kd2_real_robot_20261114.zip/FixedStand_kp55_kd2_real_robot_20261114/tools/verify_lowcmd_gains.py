#!/usr/bin/env python3
"""Verify the FixedStand / FixStand LowCmd gains from a debug_lowcmd.csv.

Usage:
    python tools/verify_lowcmd_gains.py data/lowcmd/20261112-220051_training-contract_debug_lowcmd.csv

CSV schema:
    DEBUG_LOWCMD_SCHEMA, mono_ns, lowstate_tick, state, mode_machine,
                         (slot, mode, q, dq, kp, kd, tau) x 16

Expected for 20261112-220051:
    FixedStand (state=2): 12 legs kp=55 kd=2, q=[0,0,0,0,0.8x4,-1.6x4], tau_ff=0;
                          4 wheels kp=0 kd=2, dq=0.
    FixStand   (state=1): kp20/kd3 ~894 frames + kp55/kd2 ~586 frames (+11 boundary
                          frames still Passive 0/3).
"""

from __future__ import annotations

import csv
import statistics
import sys
from pathlib import Path

LEG_COUNT = 12
MOTOR_COUNT = 16
T2 = [0.0, 0.0, 0.0, 0.0] + [0.8] * 4 + [-1.6] * 4
STATE_NAMES = {
    0: "Passive",
    1: "FixStand",
    2: "FixedStand",
    3: "PolicyHandoff",
    4: "PolicyWalk",
    5: "Brake",
    6: "ReturnStand",
    7: "FixSquat",
    8: "EmergencyDamping",
}


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__, file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    frames = {name: [] for name in STATE_NAMES.values()}
    counts = {name: 0 for name in STATE_NAMES.values()}

    with path.open(newline="", errors="replace") as stream:
        reader = csv.reader(stream)
        for row in reader:
            if not row or row[0] != "DEBUG_LOWCMD":
                continue
            state = int(float(row[3]))
            name = STATE_NAMES.get(state, f"state{state}")
            counts[name] = counts.get(name, 0) + 1
            if len(row) < 5 + 7 * MOTOR_COUNT:
                continue
            values = [float(v) for v in row[5:5 + 7 * MOTOR_COUNT]]
            frames.setdefault(name, []).append(values)

    print("state counts:", {k: v for k, v in counts.items() if v})

    fixed = frames.get("FixedStand", [])
    if not fixed:
        print("ERROR: no FixedStand frames", file=sys.stderr)
        return 1
    print(f"\nFixedStand frames={len(fixed)}")
    print(f"{'slot':>4s} {'mode':>4s} {'kp':>6s} {'kd':>5s} {'q_med':>9s} {'q_min':>9s} {'q_max':>9s} {'tau_ff':>7s}")
    for slot in range(MOTOR_COUNT):
        base = slot * 7
        mode = statistics.median(f[base + 1] for f in fixed)
        q = [f[base + 2] for f in fixed]
        kp = statistics.median(f[base + 4] for f in fixed)
        kd = statistics.median(f[base + 5] for f in fixed)
        tau = statistics.median(f[base + 6] for f in fixed)
        print(
            f"{slot:4d} {mode:4.0f} {kp:6.1f} {kd:5.1f} "
            f"{statistics.median(q):9.4f} {min(q):9.4f} {max(q):9.4f} {tau:7.3f}"
        )

    # Assert the documented contract instead of only printing it.
    ok = True
    for slot in range(LEG_COUNT):
        base = slot * 7
        kp = statistics.median(f[base + 4] for f in fixed)
        kd = statistics.median(f[base + 5] for f in fixed)
        q = statistics.median(f[base + 2] for f in fixed)
        tau = statistics.median(f[base + 6] for f in fixed)
        if (kp, kd) != (55.0, 2.0) or abs(q - T2[slot]) > 1e-6 or abs(tau) > 1e-9:
            ok = False
            print(f"MISMATCH leg slot {slot}: kp={kp} kd={kd} q={q} tau_ff={tau}")
    for slot in range(LEG_COUNT, MOTOR_COUNT):
        base = slot * 7
        kp = statistics.median(f[base + 4] for f in fixed)
        kd = statistics.median(f[base + 5] for f in fixed)
        dq = statistics.median(f[base + 3] for f in fixed)
        if (kp, kd) != (0.0, 2.0) or abs(dq) > 1e-9:
            ok = False
            print(f"MISMATCH wheel slot {slot}: kp={kp} kd={kd} dq={dq}")

    fixstand = frames.get("FixStand", [])
    if fixstand:
        combos: dict[tuple[float, float], int] = {}
        for values in fixstand:
            key = (values[4 * 7 + 4], values[4 * 7 + 5])  # slot 4 (a leg)
            combos[key] = combos.get(key, 0) + 1
        print("\nFixStand slot4 (kp,kd) frame counts:", combos)

    print("\nRESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
