#!/usr/bin/env python3
"""Extract B-gate readings from AS2-W publisher logs.

Usage:
    python tools/extract_b_gate.py data/b_gate

Reads every *.log in the directory, takes the LAST "B accepted" line per file
(a session may log a rejected press before a successful retry), prints a table
and summary statistics. Offline only; never opens DDS.
"""

from __future__ import annotations

import re
import statistics
import sys
from pathlib import Path

ACCEPT = re.compile(
    r"B accepted: pose_error=([0-9.]+) wheel_dq=([0-9.]+) "
    r"upright=([0-9.]+) quiet_dq=([0-9.]+)"
)


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else "data/b_gate")
    files = sorted(root.glob("*.log"))
    if not files:
        print(f"no *.log under {root}", file=sys.stderr)
        return 1

    rows = []
    for path in files:
        matches = ACCEPT.findall(path.read_text(errors="replace"))
        if not matches:
            print(f"SKIP (no B accepted): {path.name}", file=sys.stderr)
            continue
        pose, wheel, upright, quiet = (float(v) for v in matches[-1])
        rows.append((path.name, pose, wheel, upright, quiet))

    if not rows:
        print("no B accepted lines found", file=sys.stderr)
        return 1

    print(f"{'session':58s} {'pose_error':>10s} {'wheel_dq':>9s} {'upright':>8s} {'quiet_dq':>9s}")
    for name, pose, wheel, upright, quiet in rows:
        print(f"{name:58s} {pose:10.6f} {wheel:9.4f} {upright:8.4f} {quiet:9.4f}")

    poses = [r[1] for r in rows]
    print()
    print(
        f"n={len(poses)} mean={statistics.mean(poses):.6f} "
        f"pstdev={statistics.pstdev(poses):.6f} "
        f"min={min(poses):.6f} max={max(poses):.6f}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
